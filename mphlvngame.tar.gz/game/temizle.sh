#!/bin/sh
clear
cd /usr/game/db && sh clear_logs.sh
cd /usr/game/auth && sh clear_logs.sh
cd /usr/game/channel1/ && sh clear_logs.sh
cd /usr/game/game99/ && sh clear_logs.sh
cd /usr/game/channel1/log && rm -rf *
cd /usr/game/game99/log && rm -rf *
cd /usr/game/auth/log && rm -rf *
cd /usr/game/db/log && rm -rf *
cd /usr/game/share/locale/turkey/quest && rm -rf *.core *.dll *.log
cd /usr/game/share/data/monster/zombie_diseased_spear && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_diseased_bow && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_bigboss && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_bigboss2 && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_diseased_boss && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_diseased_dog && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_diseased_infector && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_diseased_kid && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_diseased_sword && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_general && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_ghost && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_god && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_king && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_magician && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_soldier_bow && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_soldier_scythe && rm -rf *.gr2 *.dds
cd /usr/game/share/data/monster/zombie_soldier_spear && rm -rf *.gr2 *.dds
cd /var/db/mysql && rm -rf *.err *.pid *.core *.dll *.log ibdata1 ib_logfile0 ib_logfile1 ib_logfile2 ib_logfile3 ib_logfile4 ib_logfile5 ib_logfile6 ib_logfile7 
cd /var/db/mysql && rm -rf mysql-bin.index mysql-bin.000000 mysql-bin.000001 mysql-bin.000002 mysql-bin.000003 mysql-bin.000004 mysql-bin.000005 mysql-bin.000006 
cd /var/db/mysql && rm -rf mysql-bin.000011 mysql-bin.000012 mysql-bin.000013 mysql-bin.000014 mysql-bin.000015 mysql-bin.000016 mysql-bin.000017 mysql-bin.000018 
cd /var/db/mysql && rm -rf mysql-bin.000023 mysql-bin.000024 mysql-bin.000025 mysql-bin.000026 mysql-bin.000027 mysql-bin.000028 mysql-bin.000029 mysql-bin.000030 
cd /var/db/mysql && rm -rf mysql-bin.000034 ib_logfile10 ib_logfile11 ib_logfile12 mysql-bin.000008 mysql-bin.000009 mysql-bin.000010 mysql-bin.000020 mysql-bin.000021 
cd /var/db/mysql && rm -rf mysql-bin.000032 mysql-bin.000033 mysql-bin.000031 mysql-bin.000022 mysql-bin.000019 mysql-bin.000007 ib_logfile8 ib_logfile9
cd /var/db/mysql/account && rm -rf *.TMD *.DLL *.EXE
cd /var/db/mysql/common && rm -rf *.TMD *.DLL *.EXE
cd /var/db/mysql/hotbackup && rm -rf *.TMD *.DLL *.EXE
cd /var/db/mysql/log && rm -rf *.TMD *.DLL *.EXE
cd /var/db/mysql/mysql && rm -rf *.TMD *.DLL *.EXE
cd /var/db/mysql/player && rm -rf *.TMD *.DLL *.EXE
cd /var/db/mysql/performance_schema && rm -rf *.TMD *.DLL *.EXE
clear
echo -e "\033[31mLoglar temizlendi. Server Files!\033[0m"