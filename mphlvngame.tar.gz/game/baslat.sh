#!/bin/sh
clear
cd /usr/
chmod -R 777 game
cd /var/db
chmod -R 777 mysql
cd /usr/game/share/
chmod -R 777 game
chmod -R 777 db


echo -e "\033[31mHangi CH'yi acmak istiyorsun?\033[0m"
echo -e "\033[32m 
1 - 1. Ch'yi Ac!\033[0m"

read chs

case $chs in 
1*) 

	clear
	echo -e "\033[31m \n Loglar temizleniyor ..\033[0m"
	cd /usr/game && sh temizle.sh
	sleep 2
	clear
	echo -e "\033[31m Database Ac�l�yor ..\033[0m"
	cd /usr/game/db
	./db &
	sleep 2
	clear
	echo -e "\033[31m \n Giris Aciliyor ..\033[0m"
	cd /usr/game/auth 
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n 1.Kanal Aciliyor ..\033[0m"
	cd /usr/game/channel1
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Game99 Aciliyor ..\033[0m"
	cd /usr/game/game99
	./game &
	sleep 2
	clear
	echo -e "\033[31m \n Channel 1 Acilmistir ..\033[0m"


;;

esac
