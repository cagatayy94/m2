rm -rf *.core *.dll *.log
rm -rf syserr syslog stdout PTS p2p_packet_info.txt ProfileLog libgame.stdlog.txt libgame.stderr.txt packet_info.txt udp_packet_info.txt mob_data.txt