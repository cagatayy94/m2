-- usage: add_restart_city_pos(A, B, C, D, E)
--      : A = the index of map from where player will be warped if choose restart city option.
--      : B = empire (optionally is just in-case you want to have this warp just for players from certain empire).
--      : C = X of target map where player will be teleported.
--      : D = Y of target map where player will be teleported.
--      : E = Z of target map where player will be teleported.
add_restart_city_pos(209, 1, 12779, 17347, 0)
add_restart_city_pos(209, 2, 12779, 17347, 0)
add_restart_city_pos(209, 3, 12779, 17347, 0)