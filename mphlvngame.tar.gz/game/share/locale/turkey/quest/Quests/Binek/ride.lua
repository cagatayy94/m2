quest ride begin
	state start begin
		function Ride( vnum, remain_time )
			ride_info = {
-- ride
				[71114] = { 20110,	5*60,	apply.DEF_GRADE_BONUS,	75,		75,	true	},
				[71115] = { 20110,	5*60,	apply.DEF_GRADE_BONUS,	100,	75,	false	},
				[71116] = { 20111,	5*60,	apply.DEF_GRADE_BONUS,	100,	80,	true	},
				[71117] = { 20111,	5*60,	apply.DEF_GRADE_BONUS,	150,	80,	false	},
				[71118] = { 20112,	5*60,	apply.DEF_GRADE_BONUS,	125,	85,	true	},
				[71119] = { 20112,	5*60,	apply.DEF_GRADE_BONUS,	200,	85,	false	},
				[71120] = { 20113,	5*60,	apply.ATT_GRADE_BONUS,	200,	85,	true	},
				[71121] = { 20113,	5*60,	apply.ATT_GRADE_BONUS,	300,	85,	false	},
				[71171] = { 20227,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71172] = { 20226,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71176] = { 20231,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71177] = { 20232,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},

				-- ���������� 
				[52061]= { 20213,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52062]= { 20213,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52063]= { 20213,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52064]= { 20213,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52065]= { 20213,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52066]= { 20214,	5*60, apply.ATTBONUS_MONSTER,	3 ,	0,	false,	true	},
				[52067]= { 20214,	5*60, apply.MALL_EXPBONUS,		3 ,	0,	false,	true	},
				[52068]= { 20214,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52069]= { 20214,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52070]= { 20214,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52071]= { 20215,	5*60, apply.ATTBONUS_MONSTER,	5 ,	0,	false,	true	},
				[52072]= { 20215,	5*60, apply.MALL_EXPBONUS,		5 ,	0,	false,	true	},
				[52073]= { 20215,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52074]= { 20215,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52075]= { 20215,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},
	
				-- �����ϼ���
				[52076]= { 20216,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52077]= { 20216,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52078]= { 20216,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52079]= { 20216,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52080]= { 20216,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52081]= { 20217,	5*60, apply.ATTBONUS_MONSTER,	3 ,	0,	false,	true	},
				[52082]= { 20217,	5*60, apply.MALL_EXPBONUS,		3 ,	0,	false,	true	},
				[52083]= { 20217,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52084]= { 20217,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52085]= { 20217,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52086]= { 20218,	5*60, apply.ATTBONUS_MONSTER,	5 ,	0,	false,	true	},
				[52087]= { 20218,	5*60, apply.MALL_EXPBONUS,		5 ,	0,	false,	true	},
				[52088]= { 20218,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52089]= { 20218,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52090]= { 20218,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},
				[71164] = { 20220,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71165] = { 20221,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71166] = { 20222,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},

				-- ������
				[52091]= { 20223,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52092]= { 20223,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52093]= { 20223,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52094]= { 20223,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52095]= { 20223,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52096]= { 20224,	5*60, apply.ATTBONUS_MONSTER,	3 ,	0,	false,	true	},
				[52097]= { 20224,	5*60, apply.MALL_EXPBONUS,		3 ,	0,	false,	true	},
				[52098]= { 20224,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52099]= { 20224,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52100]= { 20224,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52101]= { 20225,	5*60, apply.ATTBONUS_MONSTER,	5 ,	0,	false,	true	},
				[52102]= { 20225,	5*60, apply.MALL_EXPBONUS,		5 ,	0,	false,	true	},
				[52103]= { 20225,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52104]= { 20225,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52105]= { 20225,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},

				[52001] = { 20201,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52002] = { 20201,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52003] = { 20201,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52004] = { 20201,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52005] = { 20201,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52006] = { 20205,	5*60, apply.ATTBONUS_MONSTER,	3,	0,	false,	true	},
				[52007] = { 20205,	5*60, apply.MALL_EXPBONUS,		3,	0,	false,	true	},
				[52008] = { 20205,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52009] = { 20205,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52010] = { 20205,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52011] = { 20209,	5*60, apply.ATTBONUS_MONSTER,	5,	0,	false,	true	},
				[52012] = { 20209,	5*60, apply.MALL_EXPBONUS,		5,	0,	false,	true	},
				[52013] = { 20209,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52014] = { 20209,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52015] = { 20209,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},

				[52016]	= { 20202,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52017] = { 20202,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52018] = { 20202,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52019] = { 20202,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52020] = { 20202,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52021] = { 20206,	5*60, apply.ATTBONUS_MONSTER,	3 ,	0,	false,	true	},
				[52022] = { 20206,	5*60, apply.MALL_EXPBONUS,		3 ,	0,	false,	true	},
				[52023] = { 20206,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52024] = { 20206,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52025] = { 20206,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52026] = { 20210,	5*60, apply.ATTBONUS_MONSTER,	5 ,	0,	false,	true	},
				[52027] = { 20210,	5*60, apply.MALL_EXPBONUS,		5 ,	0,	false,	true	},
				[52028] = { 20210,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52029] = { 20210,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52030] = { 20210,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},


				[52031]= { 20204,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52032]= { 20204,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52033]= { 20204,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52034]= { 20204,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52035]= { 20204,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52036]= { 20208,	5*60, apply.ATTBONUS_MONSTER,	3 ,	0,	false,	true	},
				[52037]= { 20208,	5*60, apply.MALL_EXPBONUS,		3 ,	0,	false,	true	},
				[52038]= { 20208,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52039]= { 20208,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52040]= { 20208,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52041]= { 20212,	5*60, apply.ATTBONUS_MONSTER,	5 ,	0,	false,	true	},
				[52042]= { 20212,	5*60, apply.MALL_EXPBONUS,		5 ,	0,	false,	true	},
				[52043]= { 20212,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52044]= { 20212,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52045]= { 20212,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},


				[52046]= { 20203,	5*60, apply.ATTBONUS_MONSTER,	0,	0,	false,	true	},
				[52047]= { 20203,	5*60, apply.MALL_EXPBONUS,		0,	0,	false,	true	},
				[52048]= { 20203,	5*60, apply.MAX_HP,				0,	0,	false,	true	},
				[52049]= { 20203,	5*60, apply.DEF_GRADE_BONUS,	0,	0,	false,	true	},
				[52050]= { 20203,	5*60, apply.ATT_GRADE_BONUS,	0,	0,	false,	true	},
				[52051]= { 20207,	5*60, apply.ATTBONUS_MONSTER,	3 ,	0,	false,	true	},
				[52052]= { 20207,	5*60, apply.MALL_EXPBONUS,		3 ,	0,	false,	true	},
				[52053]= { 20207,	5*60, apply.MAX_HP,				250,	0,	false,	true	},
				[52054]= { 20207,	5*60, apply.DEF_GRADE_BONUS,	50,	0,	false,	true	},
				[52055]= { 20207,	5*60, apply.ATT_GRADE_BONUS,	30,	0,	false,	true	},
				[52056]= { 20211,	5*60, apply.ATTBONUS_MONSTER,	5 ,	0,	false,	true	},
				[52057]= { 20211,	5*60, apply.MALL_EXPBONUS,		5 ,	0,	false,	true	},
				[52058]= { 20211,	5*60, apply.MAX_HP,				500,	0,	false,	true	},
				[52059]= { 20211,	5*60, apply.DEF_GRADE_BONUS,	150,	0,	false,	true	},
				[52060]= { 20211,	5*60, apply.ATT_GRADE_BONUS,	100,	0,	false,	true	},

-- ride_mystery_boxes
				[71124] = { 20114,	5*60,	apply.MOV_SPEED,	100,		1,	false,	false,	false},
				[71125] = { 20115,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71126] = { 20116,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71127] = { 20117,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71128] = { 20118,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71137] = { 20120,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71138] = { 20121,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71139] = { 20122,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71140] = { 20123,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71141] = { 20124,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},
				[71142] = { 20125,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},

-- ride_halloween
				[71161] = { 20219,	5*60,	apply.MOV_SPEED,	60,		1,	false,	false,	false},

-- ride_ramadan
				[71131] = { 20119,	5*60,	apply.MOV_SPEED, 60,	1,	false	},
				[71132] = { 20119,	5*60,	apply.MOV_SPEED, 60,	1,	false	},
				[71133] = { 20119,	5*60,	apply.MOV_SPEED, 60,	1,	false	},
				[71134] = { 20119,	5*60,	apply.MOV_SPEED, 60,	1,	false	},
				}

			if pc.level < ride_info[vnum][5] then
				say("")
				syschat("Bine�i kullanabilmek i�in seviyeniz yeterli de�il.")
				say("")
			else
				if 112 == pc.get_map_index() then
					return
				end
				if ride_info[vnum][2] == 0 and remain_time != 0 then
					pc.mount( ride_info[vnum][1], remain_time*60 )
					pc.mount_bonus( ride_info[vnum][3], ride_info[vnum][4], remain_time*60 )
				else
					pc.mount( ride_info[vnum][1], ride_info[vnum][2] )
					pc.mount_bonus( ride_info[vnum][3], ride_info[vnum][4], ride_info[vnum][2] )
				end

				if true == ride_info[vnum][6] then
					pc.remove_item(vnum, 1)
				end	
			end	
		end

		when login begin
			local vnum, remain_time = pc.get_special_ride_vnum()
			if vnum <=  71113 or vnum >71121 then
				return
			end
			if 0 != vnum then
				ride.Ride(vnum, remain_time)
			end
		end

		when 71114.use or 71115.use or 71116.use or 71117.use or 71118.use or 71119.use or 71120.use or 71121.use 
				or 71171.use or 71172.use or 71176.use or 71177.use or 71124.use or 71125.use or 71126.use or 71127.use or 71128.use or 71137.use or 71138.use
				or 71139.use or 71140.use or 71141.use or 71142.use or 71161.use or 71131.use or 71132.use or 71133.use or 71134.use or

			52061.use or 52062.use or 52063.use or 52064.use or 52065.use or 52066.use or 52067.use or 52068.use or 52069.use or 52070.use or 52071.use or 52072.use or 52073.use or 52074.use or 52075.use or 
			52076.use or 52077.use or 52078.use or 52079.use or 52080.use or 52081.use or 52082.use or 52083.use or 52084.use or 52085.use or 52086.use or 52087.use or 52088.use or 52089.use or 52090.use or
			52091.use or 52092.use or 52093.use or 52094.use or 52095.use or 52096.use or 52097.use or 52098.use or 52099.use or 52100.use or 52101.use or 52102.use or 52103.use or 52104.use or 52105.use	or

			52001.use or 52002.use or 52003.use or 52004.use or 52005.use  or 52006.use or 52007.use or 52008.use or 52009.use or 52010.use  or 52011.use or 52012.use or 52013.use or 52014.use or 52015.use or
			52016.use or 52017.use or 52018.use or 52019.use or 52020.use  or 52021.use or 52022.use or 52023.use or 52024.use or 52025.use  or 52026.use or 52027.use or 52028.use or 52029.use or 52030.use or
			52031.use or 52032.use or 52033.use or 52034.use or 52035.use  or 52036.use or 52037.use or 52038.use or 52039.use or 52040.use  or 52041.use or 52042.use or 52043.use or 52044.use or 52045.use or
		  52046.use or 52047.use or 52048.use or 52049.use or 52050.use or  52051.use or 52052.use or 52053.use or 52054.use or 52055.use or 52056.use or 52057.use or 52058.use or 52059.use or 52060.use 
				begin

			 if pc.is_polymorphed() then
				 syschat("D�n��m�� haldeyken binek kullanamazs�n.")
			elseif false == pc.is_riding() then
			 	if true == horse.is_summon() then
					horse.unsummon()
				end
				 ride.Ride(item.vnum, 0)
			 else
				 syschat("Zaten bir binek kullan�yorsun.")
			 end
		end
	end
end
