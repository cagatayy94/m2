quest gemsistem begin
	state start begin
		when login begin
			local gem = pc.mphlvn_gem_bak()
			cmdchat("gem "..gem)
			send_letter("Gaya Sistemi ")
		end

		when button or info begin
			say_title("Merhaba "..pc.get_name())
			local gem = pc.mphlvn_gem_bak()
			say_reward("Mevcut Gaya Puan�n : "..gem)
			say("Ne yapmak istiyorsun ?")
			say("")
			local menu
			if pc.is_gm() then
				menu = select("Bilgi Al ", "�d�ller ", "�d�l Al ", "�d�l Ge�mi�i ", "Kapat ", "Y�netim ")
			else
				menu = select("Bilgi Al ", "�d�ller ", "�d�l Al ", "�d�l Ge�mi�i ", "Kapat ")
			end
			if menu == 6 then
				say_title("Y�netim Paneline Ho� Geldin "..pc.get_name())
				say("Ne yapmak istiyorsun ?")
				say("")
				local islem = select("�tem Ekle ", "�tem Sil ", "Vazge� ")
				if islem == 4 then
					-- send_letter("Gaya Sistemi ")
				elseif islem == 2 then
					say_title("Gaya Sistemi : ")
					say("")
					say("Silmek istedi�in �d�l� se�.")
					local vnum, count, price, isim, id = gemsistem.odul_al_sil() 
					table.insert(isim,"Vazge� ") 
					local sirala = select_table(isim) 
					if(table.getn(isim) == sirala) then 
						-- send_letter("Gaya Sistemi ")
						return
					end
					say_reward(item_name(vnum[sirala])) 
					say_reward("Adet : "..count[sirala]) 
					say_reward("Gerekli Gaya : "..price[sirala]) 
					say_item_vnum(vnum[sirala])
					say("")
					say("")
					say("")
					local al_id = tonumber(id[sirala])
					local al = select("Sil ","Vazge� ")
					if al == 2 then
						-- send_letter("Gaya Sistemi ")
					else
						say("�d�l silindi.")
						gemsistem.odul_sil(al_id)
						-- wait()
						-- send_letter("Gaya Sistemi ")
					end
				elseif islem == 1 then
					say_title("Gaya Sistemi : ")
					say("")
					say("Item vnum girin l�tfen : ")
					say("")
					local v_giris = tonumber(input(''))
					local kontrol = gemsistem.item_bilgi(v_giris)
					if kontrol == "bos" then
						say("Ge�ersiz item kodu.")
						-- wait()
						-- send_letter("Gaya Sistemi ")
						return
					else
						say("Adet Girin : ")
						say("")
						local a_giris = tonumber(input(''))
						if a_giris < 0 or nil then
							say("Ge�ersiz de�er.")
							-- wait()
							-- send_letter("Gaya Sistemi ")
							return
						else
							say("De�er (Gaya) Girin : ")
							say("")
							local d_giris = tonumber(input(''))
							if d_giris < 0 or nil then
								say("Ge�ersiz de�er.")
								-- wait()
								-- send_letter("Gaya Sistemi ")
								return
							else
								say_item_vnum(v_giris)
								say_reward("Adet : "..a_giris)
								say_reward("De�er (Gaya) : "..d_giris)
								say("")
								say("")
								say("")
								say("")
								local a = select(locale.yes, locale.no)
								if a == 1 then
									say("Item eklendi.")
									gemsistem.item_ekle(v_giris,a_giris,d_giris)
									-- wait()
									-- send_letter("Gaya Sistemi ")
								else
									-- send_letter("Gaya Sistemi ")
								end
							end
						end
					end
				end
			elseif menu == 5 then
				-- send_letter("Gaya Sistemi ")
			elseif menu == 4 then
				say_title("Gaya Sistemi : ")
				say("")
				say("�d�l ge�mi�in a�a��da s�raland�.")
				local vnum, count, price, isim, zaman = gemsistem.loglar(pc.get_name())
				table.insert(isim,"Vazge� ") 
				local sirala = select_table(isim) 
				if(table.getn(isim) == sirala) then 
					-- send_letter("Gaya Sistemi ")
					return; 
				end
				say("Sat�n Ald���n �teme Dair Ayr�nt�lar : ")
				say_reward(item_name(vnum[sirala])) 
				say_reward("Adet : "..count[sirala]) 
				say_reward("Gaya : "..price[sirala]) 
				say_reward("Tarih : "..zaman[sirala]) 
				say_item_vnum(vnum[sirala])
				say("")
				-- wait()
				-- send_letter("Gaya Sistemi ")				
			elseif menu == 1 then
				say_title("Gaya Sistemi : ")
				say("")
				say("Belli ba�l� bosslar� keserek ve ")
				say("oyuncular� keserek Gaya puan� kazanabilirsin.")
				say("Her boss farkl� Gaya puan� verir.")
				say("Bu puanlar� kullanarak �d�ller ")
				say("kazanabilirsin. Ayn� oyuncuyu tekrar ")
				say("tekrar �ld�rmek avantaj kazand�rm�yor.")
				say("Ayn� oyuncuyu 3 kere kestikten sonra o ")
				say("oyuncudan 1 saat boyunca Gaya kazanamaz ")
				say("hale geliyorsun.")
				say("")
				-- wait()
				-- send_letter("Gaya Sistemi ")
			elseif menu == 2 then
				say_title("Gaya Sistemi : ")
				say("�d�l listesi a�a��da s�raland�.")
				local vnum, count, price, isim = gemsistem.oduller()
				local toplam = table.getn(isim)
				if toplam > 8 then
					say_size(350,300)
				end
				for num1, str1 in ipairs(isim) do
					if num1 <= 10 then
						say_reward(isim[num1])
					end
				end
				wait()
				for num1, str1 in ipairs(isim) do
					if num1 > 10 then
						say_reward(isim[num1]) 
					end
				end
				-- wait()
				-- send_letter("Gaya Sistemi ")
			elseif menu == 3 then
				say_title("Gaya Sistemi : ")
				say("")
				say("Almak istedi�in �d�l� se�.")
				local vnum, count, price, isim = gemsistem.oduller() 
				local toplam = table.getn(isim)
				if toplam > 8 then
					say_size(350,350)
				end
				table.insert(isim,"Vazge� ") 
				local sirala = select_table(isim) 
				if(table.getn(isim) == sirala) then 
					-- send_letter("Gaya Sistemi ")
					return; 
				end
				say_reward(item_name(vnum[sirala])) 
				say_reward("Adet : "..count[sirala]) 
				say_reward("Gerekli Gaya : "..price[sirala]) 
				say_item_vnum(vnum[sirala])
				say("")
				say("")
				say("")
				local al_vnum, al_count, al_price, al_isim = tonumber(vnum[sirala]), tonumber(count[sirala]), tonumber(price[sirala]), isim[sirala]
				local al = select("�d�l� Al ","Vazge� ")
				if al == 2 then
					-- send_letter("Gaya Sistemi ")
				else
					local gem = pc.mphlvn_gem_bak()
					if gem < al_price then
						say("Yeterli Gaya'ye sahip de�ilsin.")
						say("")
						say_reward("Gereken Gaya Puan� : "..al_price)
						say_reward("Mevcut Gaya Puan� : "..gem)
						-- wait()
						-- send_letter("Gaya Sistemi ")
						return
					end
					pc.mphlvn_gem_ver(gem-al_price,pc.get_player_id())
					cmdchat("gem "..tonumber(gem-al_price))
					pc.give_item2(al_vnum, al_count)
					say(al_price.." Gaya kar��l���nda ")
					say(al_count.." adet "..item_name(al_vnum).." kazand�n.")
					say("")
					say("Daha �nce sat�n ald���n �d�lleri ")
					say("�d�l Ge�mi�i sekmesinden g�rebilirsin.")
					gemsistem.gem_log_gir(pc.get_name(), al_vnum, al_count, al_price)
					-- wait()
					-- send_letter("Gaya Sistemi ")
				end
			end
        end
		
		
		when kill with npc.is_pc() == false begin
			local boss = npc.get_race()
			local bos = gemsistem.bosslar(boss)
			local id = pc.get_player_id()
			local gem = pc.mphlvn_gem_bak()
			if null == bos then
				return
			else
				local gem_bos = bos[1]
				pc.mphlvn_gem_ver(gem+bos[1],id)
				cmdchat("gem "..gem+bos[1])
				chat(mob_name(boss).." kesti�in i�in "..bos[1].." Gaya kazand�n. Toplam Gaya Puan�n : "..pc.mphlvn_gem_bak())
			end
		end
		when kill with npc.is_pc() and pc.get_map_index() != 28 and pc.get_map_index() != 200 begin
			local krallik_modu = 0 -- 0 Kapal� 1 Aktif (Aktif oldu�unda bayrak farketmeksizin gem kazan�l�r.)
			local ip_kontrol = 0 -- 0 Kapal� 1 Aktif (Aktif oldu�unda ip taramas� yapar.)
			----Ben-----------------
			local m_lv = pc.get_level()
			local m_emp = pc.get_empire()
			local m_gem = pc.mphlvn_gem_bak()
			local m_id = pc.get_player_id()
			local m_name = pc.get_name()
			local m_ip = pc.get_ip()
			--------------------------
			local vid = npc.get_vid()
			local old_pc = pc.select(vid)
			if old_pc != 0 then
				------Rakip--------------
				local r_lv = pc.get_level()
				local r_name = pc.get_name()
				local r_emp = pc.get_empire()
				local r_gem = pc.mphlvn_gem_bak()
				local r_id = pc.get_player_id()
				local r_ip = pc.get_ip()
				------------------------
				if r_emp != m_emp and krallik_modu == 0 then
					if m_ip == r_ip and ip_kontrol == 1 then
						syschat("Ayn� IP'den giri� yapm�� bir oyuncuya �ld�n. Gaya kaybetmedin.")
						pc.select(old_pc)
						syschat("Ayn� IP'den giri� yapm�� bir oyuncu kestin. Gaya kazanamad�n.")
						return
					end
					if r_lv < 90 or m_lv < 90 then
						pc.select(old_pc)
						syschat("90 seviye ve �st� oldu�unda Gaya kazanabilirsin.")
						return
					end
					if r_lv - m_lv < 10 or m_lv - r_lv < 10 then
						local sure, sayi = gemsistem.kisi_bilgi(m_name, r_name)
						if sure == "bos" then
							gemsistem.gem_bilgi_gir(m_name, r_name)
						end
						local sure, sayi = gemsistem.kisi_bilgi(m_name, r_name)
						if get_time() > tonumber(sure) then
							gemsistem.gem_log_sifirla(m_name, r_name)
							if sayi >= 2 then
								gemsistem.gem_blok(m_name, r_name)
								chat("Ayn� oyuncuya �ok s�k �ld���n i�in 60 dakika boyuncu bu oyuncudan Gaya kaybetmeyeceksin.")
								pc.select(old_pc)
								chat("Ayn� oyuncuyu �ok s�k �ld�rd���n i�in 60 dakika boyuncu bu oyuncudan Gaya kazanamayacaks�n.")
								return
							else
								gemsistem.gem_spam(m_name, r_name)
								if r_gem-1 <= 0 then
									chat("S�f�r puana d��t���n i�in art�k Gaya kaybetmeyeceksin.")
									pc.mphlvn_gem_ver(0,r_id)
									cmdchat("gem 0")
								else
									chat(m_name.." oyuncusuna �lerek 1 Gaya puan� kaybettin. Mevcut puan : "..r_gem-1)
									pc.mphlvn_gem_ver(r_gem-1,r_id)
									cmdchat("gem "..r_gem-1)
								end
								pc.select(old_pc)
								chat(r_lv.." seviye "..r_name.." oyuncusunu �ld�rerek 1 Gaya kazand�n. Mevcut puan�n : "..(m_gem+1))
								pc.mphlvn_gem_ver(m_gem+1,m_id)
								cmdchat("gem "..m_gem+1)
							end
						else
							gemsistem.gem_blok(m_name, r_name)
							chat("Ayn� oyuncuyu �ok s�k �ld���n i�in art�k bu oyuncuda Gaya kaybetmeyeceksin.")
							chat("Kalan s�re "..gemsistem.kalan_sure(sure - get_time()).." ")
							pc.select(old_pc)
							chat("Ayn� oyuncuyu �ok s�k �ld�rd���n i�in 60 dakika boyuncu bu oyuncudan Gaya kazanamayacaks�n.")
							chat("Kalan s�re "..gemsistem.kalan_sure(sure - get_time()).." ")
							return
						end
					end
				else
					pc.select(old_pc)
					chat("Kendi krall���ndan birini �ld�rerek Gaya kazanamazs�n.")
					return
				end
			end
		end
		
		function oduller() 
            local query=[[SELECT * FROM player.gem_odul ORDER BY id DESC;]]
			local res1, res2 = mysql_direct_query2(query)
            if(res1 == 0) then 
                return -1 
            end 
            local vnum, count, price, isim  = {},{},{},{}
            table.foreachi(res2, 
                function(n,p) 
                    vnum[n],count[n],price[n],isim[n] = res2[n].vnum, res2[n].count, res2[n].price, item_name(res2[n].vnum).."x"..res2[n].count.."    Gaya:"..res2[n].price
            end) 
            return vnum, count, price, isim
        end 
		
		function loglar(ben) 
            local query=[[SELECT * FROM player.gem_odul_log WHERE name = '"..ben.."' ORDER BY timee DESC;]]
			local res1, res2 = mysql_direct_query2(query)
            if(res1 == 0) then 
                return -1 
            end 
            local vnum, count, price, isim, zaman  = {},{},{},{},{}
            table.foreachi(res2, 
                function(n,p) 
                    vnum[n],count[n],price[n],isim[n],zaman[n] = res2[n].vnum, res2[n].count, res2[n].price, item_name(res2[n].vnum).."    Gaya:"..res2[n].price, res2[n].timee
            end) 
            return vnum, count, price, isim, zaman
        end 
		
		function odul_al_sil()
			local query=[[SELECT * FROM player.gem_odul ORDER BY id desc;]]
			local res1, res2 = mysql_direct_query2(query)
            if(res1 == 0) then 
                return -1 
            end 
            local vnum, count, price, isim, id  = {},{},{},{},{}
            table.foreachi(res2, 
                function(n,p) 
                    vnum[n],count[n],price[n],isim[n],id[n] = res2[n].vnum, res2[n].count, res2[n].price, item_name(res2[n].vnum).."    Gaya:"..res2[n].price, res2[n].id
            end) 
            return vnum, count, price, isim, id
		end
		
		
		function kalan_sure(ipe) 			
			if ipe >= get_global_time() then
				seconds = ipe - get_global_time()
			else
				seconds = (get_global_time() + ipe) - get_global_time()
			end
			
			
			local days = 0
			local hours = math.floor(seconds / 3600)
			local mins = math.floor((seconds - (hours*3600)) / 60)
			local secs = math.floor(seconds - hours*3600 - mins*60 )
			local t = ""
			if tonumber(hours) >= 24 then
				days = math.floor(hours / 24)
				hours = math.floor(hours - (days*24))
			end
			if tonumber(days) == 1 then
				t = t..days.." Gun "
			elseif tonumber(days) >= 1 then
				t = t..days.." Gun "
			end
			if tonumber(hours) == 1 then
				t = t..hours.." Saat "
			elseif tonumber(hours) >= 1 then
				t = t..hours.." Saat "
			end
			if tonumber(mins) == 1 then
				t = t..mins.." Dakika "
			elseif tonumber(mins) >= 1 then
				t = t..mins.." Dakika "
			end
			if tonumber(secs) == 1 then
				t = t..secs.." Saniye "
			elseif tonumber(secs) >= 1 then
				t = t..secs.." Saniye "
			end
			if t == "" then
				return "(!)"
			end
			return t
		end
		
		function gem_blok(ben, rakip)
			local ekle = get_time()+60*60
			local query=[[UPDATE player.gem_log SET sure = '"..ekle.."', sayi = 0 WHERE olduren = '"..ben.."' and olen = '"..rakip.."';]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function gem_bilgi_gir(ben, rakip)
			local query=[[INSERT INTO player.gem_log (olduren, olen, sayi, sure) VALUES ('"..ben.."', '"..rakip.."', 0,0);]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function item_ekle(vnum, count, price)
			local query=[[INSERT INTO player.gem_odul (vnum, count, price) VALUES ('"..vnum.."', '"..count.."', '"..price.."');]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function gem_log_gir(name, vnum, count, price)
			local query=[[INSERT INTO player.gem_odul_log (name, vnum, count, price, timee) VALUES ('"..name.."', '"..vnum.."', '"..count.."','"..price.."', now());]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function gem_log_sifirla(ben, rakip)
			local query=[[UPDATE player.gem_log SET sure = 0 WHERE olduren = '"..ben.."' and olen = '"..rakip.."';]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function odul_sil(id)
			local query=[[DELETE FROM player.gem_odul WHERE id = '"..id.."';]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function gem_spam(ben, rakip)
			local query=[[UPDATE player.gem_log SET sayi = sayi+1 WHERE olduren = '"..ben.."' and olen = '"..rakip.."';]]
			local res1, res2 = mysql_direct_query2(query)
		end
		
		function odul_al()
			local query=[[SELECT * FROM player.gem_odul ORDER BY id desc;]]
			local res1, res2 = mysql_direct_query2(query)
			local odul = res2[1].vnum
			local adet = res2[1].count
			local deger = res2[1].count
			return odul, adet, deger
		end
		
		function kisi_bilgi(ben, rakip)
			local query=[[SELECT * FROM player.gem_log WHERE olduren = '"..ben.."' and olen = '"..rakip.."';]]
			local res1, res2 = mysql_direct_query2(query)
			local sure, sayi
			if res1 == nil or res1 == 0 then
				sure = "bos"
			else
				sure = res2[1].sure
				sayi = res2[1].sayi
			end
			
			return sure, sayi
		end
		
function item_bilgi(vnum)
   local durum
   if vnum == nil or vnum == " " or vnum == "" then
    durum = "bos"
   end
   local query=[[SELECT * FROM player.item_proto WHERE vnum = '"..vnum.."';]]
   local res1, res2 = mysql_direct_query2(query)
   
   if res1 == nil or res1 == 0 then
    durum = "bos"
   else
    durum = "dolu"
   end
   
   return durum
  end
		function bosslar(boss)
			bosslar = {
				[691]		= {1},
				[1901]		= {1},
				[2206]		= {1},
				[2091]		= {1},
				[2191]		= {1},
				[792]		= {1},
				[1304]		= {1},
				[2306]		= {1},
				[1192]		= {1},
				[2492]		= {1},
				[2493]		= {1},
				[1093]		= {1},
				[2598]		= {1},
			}

			boss = tonumber(boss)

			return bosslar[boss]
		end 
	end
end