quest dungeons_ranking begin
	state start begin
		when 20421.chat."S�ralama listesi" begin
			say("")
			local menu = select("Meley'in �ni", "�ptal")
			if menu == 1 then
				MeleyLair.OpenRanking()
				setskin(NOWINDOW)
				return
			else
				setskin(NOWINDOW)
				return
			end
		end
	end
end