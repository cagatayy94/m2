quest sash begin
	state start begin
		when 20406.chat."Bir Omuz Ku�ag� Nedir?" begin
			say_title(mob_name(20406))
			say("Omuz ku�ag� sana iki imkan sunar:")
			say("Kombinasyon ve emi�.")
			say("")
			say("Kombinasyon ayn� derecedeki iki ku�akla")
			say("ger�ekle�tirilebilir. Kombine edilen iki ku�ak")
			say("Daha de�erli bir ku�ak meydana getirir.")
			say("")
			say("Emi� i�leminde bir silah veya z�rh �zerinde")
			say("bulunan bonuslar")
			say("�e�itli oranlarla omuz ku�a��na aktar�l�r")
			say("Emi� oran� (%) ku�a��n derecesine ba�l�d�r.Bonus")
			say("emi�i islemi secilen silah ve z�rh geri")
			say("dond�r�lemez �ekilde yok edilir.")
		end
		
		when 20406.chat."Kombinasyon" begin
			say_title(mob_name(20406))
			say("")
			say("�ki ku�a�� kombine mi etmek istiyorsun?")
			say("")
			local confirm = select("Evet", "Hay�r")
			if confirm == 2 then
				return
			end
			
			setskin(NOWINDOW)
			pc.open_sash(true)
		end
		
		when 20406.chat."Bonus Emi�i" begin
			say_title(mob_name(20406))
			say("")
			say("Silah veya z�rh�ndan bonus mu emmek istersin?")
			say("")
			local confirm = select("Evet", "Hay�r")
			if confirm == 2 then
				return
			end
			
			setskin(NOWINDOW)
			pc.open_sash(false)
		end
	end
end