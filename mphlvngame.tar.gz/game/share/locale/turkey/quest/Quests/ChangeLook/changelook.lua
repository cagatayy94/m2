quest changelook begin
	state start begin
		when 20406.chat."Yans�tma" begin
			say_title(mob_name(20406))
			say("")
			say("�tem yans�tma itemlerinin g�r�n���n� sonsuza dek de�i�tirmeni sa�lar")
			say("bu etki geri al�nd���nda g�r�n��� i�in verdi�in item iade edilmez")
			say("devam etmek istiyor musun?")
			say("")
			local confirm = select("Evet", "Hay�r")
			if confirm == 2 then
				return
			end
			
			setskin(NOWINDOW)
			pc.open_changelook(true)
		end
	end
end