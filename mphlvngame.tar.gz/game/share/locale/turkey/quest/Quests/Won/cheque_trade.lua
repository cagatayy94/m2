quest cheque_trade begin
	state start begin
		when warehouse_keeper.chat."D�viz B�rosu" begin
			local wonToYang = 100000000 -- 100kk
			local s = select("Yang'a �evir", "Won'a �evir", "Kapat")
			if s == 1 then
				say("Yang'a �evir")
				say("Ne kadar yang istersin ? ")
				say("1 Won = 100.000.000 Yang ")
				say("Min 1 Won - Maks. 19 Won ")
				local won = input_number()
				if won < 1 or won > 19 then
					say("Verilerinizi kontrol ediniz ! ")
					say("Maks. won miktar� : 99 ")
					say("Maks. yang miktar� : 2.000.000.000 ")
					return
				end
				local newMoney = wonToYang * won
				say("Yang'a �evir")
				say("Al�nan won miktar� : "..won.." Won")
				say("Verilen yang miktar� : "..newMoney.." Yang")
				local s2 = select("D�n��t�r","Kapat")
				if s2 == 2 then return end
				if pc.get_cheque() < won then
					say("Yetersiz won ! ")
					return 
				end
				if pc.get_gold() + newMoney > 2000000000 then --2kkk
					say("Envanterinizde �ok fazla yang mevcut ! ")
					return
				end
				pc.change_cheque(-won)
				pc.change_gold(newMoney)
			elseif s == 2 then
				say("Won'a �evir")
				say("Ne kadar won istersin ? ")
				say("1 Won = 100.000.000 Yang")
				say("Min 1 Won - Maks. 19 Won ")
				local won = input_number()
				if won < 1 or won > 19 then
					say("Verilerinizi kontrol ediniz ! ")
					say("Maks. won miktar� : 99 ")
					say("Maks. yang miktar� : 2.000.000.000 ")
					return
				end
				local newMoney = (wonToYang * won) + wonToYang * won * 3 / 100
				say("3% Vergi")
				say("Won'a �evir")
				say("Al�nan yang miktar� : "..newMoney.." Yang")
				say("Verilen won miktar� : "..won.." Won")
				local s2 = select("D�n��t�r","Kapat")
				if s2 == 2 then return end
				if pc.get_gold() < newMoney then
					say("Yetersiz yang ! ")
					return 
				end
				if pc.get_cheque() + won > 99 then --99 max won
					say("Envanterinizde �ok fazla won mevcut ! ")
					return
				end
				pc.change_cheque(won)
				pc.change_gold(-newMoney)
			else return end
		end
	end
end

