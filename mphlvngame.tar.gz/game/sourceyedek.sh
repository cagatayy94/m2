clear
echo
echo -e "\033[32mMETIN2! \033[0m"
echo
echo -e "\033[32m
ISLEMINIZ GERCEKLESTIRILIYOR. \n
LUTFEN BEKLEYINIZ. \033[0m"
echo
cd /usr/src/
rm -rf _s3ll__src_server.git.tar.gz
wait
tar cvzf _s3ll__src_server.git.tar.gz _s3ll__src_server.git
wait
clear
echo
echo -e "\033[32mMETIN2! \033[0m"
echo -e "\033[32m
ISLEM BASARILI. \n
LOGLAR TEMIZLENDI YEDEKLER ALINDI! \033[0m"
echo
